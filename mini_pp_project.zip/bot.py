import telebot, requests, json
from telebot import types
from datetime import datetime

# ------------------ TOKEN VA ADMIN ------------------
API_TOKEN = "7750550790:AAHDKl0H8JpWM3867oH5K9r7138HiTpeDss"
bot = telebot.TeleBot(API_TOKEN)
ADMINS = [1903100748]

# ------------------ JSONBIN MA'LUMOTLARI ------------------
BIN_ID = "68c806ded0ea881f407e8f1d"
API_KEY = "$2a$10$KJgIisXYAe76dAUceAx/q.ClLQzoPPJgMO9LGklLjlu721WIl2qku"
BASE_URL = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
headers = {"X-Master-Key": API_KEY, "Content-Type": "application/json"}

# ------------------ SAQLASH / O'QISH ------------------
def load_data():
    res = requests.get(BASE_URL + "/latest", headers=headers)
    if res.status_code == 200:
        return res.json()["record"]
    return {"products": [], "sales": [], "expenses": []}

def save_data(data):
    requests.put(BASE_URL, headers=headers, data=json.dumps(data))

# ------------------ START ------------------
@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row('Admin', 'Xaridor')
    bot.send_message(message.chat.id, "Salom! Siz admin yoki xaridor?", reply_markup=markup)

# ------------------ ADMIN PANEL ------------------
@bot.message_handler(func=lambda m: m.text == "Admin" and m.chat.id in ADMINS)
def admin_panel(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row('Mahsulot qo‘shish', 'Mahsulotlarni ko‘rish')
    markup.row('Savdolar', 'Xarajatlar')
    markup.row('Mini App 🚀')
    bot.send_message(message.chat.id, "📊 Admin panel", reply_markup=markup)

# ------------------ MINI APP LINK ------------------
@bot.message_handler(func=lambda m: m.text == "Mini App 🚀")
def mini_app(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(types.KeyboardButton(
        "Mini App 🔗",
        web_app=types.WebAppInfo(url="https://iqboljonabdusamadov.github.io/mini.pp/")
    ))
    bot.send_message(message.chat.id, "Mini App’ni ochish uchun tugmani bosing 👇", reply_markup=markup)

print("✅ Bot ishga tushdi...")
bot.infinity_polling()
